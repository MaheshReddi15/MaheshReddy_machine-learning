#!/usr/bin/env python
# coding: utf-8

# In[32]:


import streamlit as st
from sklearn.datasets import load_iris, load_digits
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import StandardScaler


# In[33]:


# App title and description
st.title('Machine Learning Classifier App')
st.markdown('This app allows you to interact with machine learning classifiers.')

# Sidebar section
st.sidebar.header('Settings')

# Dataset selection
st.sidebar.subheader('Select Dataset')
dataset_name = st.sidebar.selectbox('Choose dataset', ('IRIS', 'Digits'))

# Load datasets using st.cache_data
@st.cache_data()
def load_data(dataset_name):
    if dataset_name == 'IRIS':
        iris = load_iris()
        return iris.data, iris.target, iris.feature_names
    elif dataset_name == 'Digits':
        digits = load_digits()
        return digits.data, digits.target, [f'Pixel {i}' for i in range(digits.data.shape[1])]

# Load data
data, target, feature_names = load_data(dataset_name)

# Display dataset shape
st.sidebar.write(f'{dataset_name} dataset shape: {data.shape}')


# In[34]:


# Sidebar - Model selection
st.sidebar.subheader('Select Model')
model_name = st.sidebar.selectbox('Choose model', ('Logistic Regression', 'Neural Networks', 'Naïve Bayes'))

# Function to train and evaluate the selected model
def train_evaluate_model(model_name, X_train, X_test, y_train, y_test):
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    if model_name == 'Logistic Regression':
        model = LogisticRegression(max_iter=1000)  # Increase max_iter to allow more iterations
    elif model_name == 'Neural Networks':
        model = MLPClassifier(hidden_layer_sizes=(100, 50), max_iter=1000)
    elif model_name == 'Naïve Bayes':
        model = GaussianNB()

    # Train the model
    model.fit(X_train_scaled, y_train)

    # Evaluate the model
    accuracy = model.score(X_test_scaled, y_test)
    return model, accuracy

# Split data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(data, target, test_size=0.2, random_state=42)

# Train and evaluate the selected model
model, accuracy = train_evaluate_model(model_name, X_train, X_test, y_train, y_test)

# Display model accuracy
st.sidebar.write(f'Model Accuracy: {accuracy:.2f}')


# In[35]:


# Main content area
st.header('Prediction')
st.markdown('Input feature values and click the button to make predictions.')

# Input feature values dynamically based on the selected dataset
user_inputs = []
for i, feature_name in enumerate(feature_names):
    value = st.number_input(f'Enter {feature_name}', value=0.0)
    user_inputs.append(value)

# Button to make predictions
if st.button('Make Predictions'):
    if model_name == 'Logistic Regression':
        scaler = StandardScaler()
        scaled_inputs = scaler.fit_transform([user_inputs])
        prediction = model.predict(scaled_inputs)
    else:
        prediction = model.predict([user_inputs])

    # Display prediction result
    if dataset_name == 'IRIS':
        target_names = ['Setosa', 'Versicolor', 'Virginica']
        prediction_label = target_names[prediction[0]]
        st.success(f'Predicted Iris Species: {prediction_label}')
    elif dataset_name == 'Digits':
        st.success(f'Predicted Digit: {prediction[0]}')

# Display user inputs
st.subheader('User Inputs')
for feature_name, value in zip(feature_names, user_inputs):
    st.write(f'{feature_name}: {value}')






